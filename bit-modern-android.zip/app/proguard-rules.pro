# ProGuard rules for Bit
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * { public protected *; }
