package com.nooleus.bit

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nooleus.bit.ui.theme.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BitTheme {
                BitScreen()
            }
        }
    }
}

@Composable
fun BitScreen(viewModel: BitViewModel = viewModel()) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val state = viewModel.state

    // Анимация пульсации кнопки
    val pulseAnim = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulseAnim.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Анимация движения сетки
    val gridOffset by pulseAnim.animateFloat(
        initialValue = 0f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gridOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TronBlack)
            .drawBehind {
                drawTronGrid(gridOffset)
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                focusManager.clearFocus()
            },
        contentAlignment = Alignment.Center
    ) {
        // Плавающие частицы
        FloatingParticles()

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Заголовок BIT
            Text(
                text = "BIT",
                style = MaterialTheme.typography.displayMedium,
                color = TronCyan,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(bottom = 32.dp)
                    .drawBehind {
                        // Glow эффект
                        drawCircle(
                            color = TronCyan.copy(alpha = 0.15f),
                            radius = size.maxDimension * 0.6f,
                            center = center
                        )
                    }
            )

            // Поле ввода вопроса
            OutlinedTextField(
                value = viewModel.question,
                onValueChange = viewModel::onQuestionChange,
                placeholder = {
                    Text(
                        "Задай вопрос…",
                        color = TronCyan.copy(alpha = 0.4f),
                        style = MaterialTheme.typography.bodyLarge
                    )
                },
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = TronCyan,
                    textAlign = TextAlign.Center
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        if (viewModel.question.isNotBlank() && state is BitState.Idle) {
                            vibrate(context)
                            viewModel.askBit()
                        }
                    }
                ),
                shape = MaterialTheme.shapes.medium,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TronCyan,
                    unfocusedBorderColor = TronCyan.copy(alpha = 0.3f),
                    focusedContainerColor = TronCyan.copy(alpha = 0.05f),
                    unfocusedContainerColor = TronCyan.copy(alpha = 0.02f),
                    cursorColor = TronCyan
                ),
                modifier = Modifier
                    .widthIn(max = 360.dp)
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Кнопка "Нажми для ответа"
            val isThinking = state is BitState.Thinking
            val btnScale = if (isThinking) 0.9f else if (state is BitState.Idle) pulseScale else 1f
            val btnColor = when {
                isThinking -> TronOrange
                state is BitState.Answer && state.isYes -> TronGreen
                state is BitState.Answer && !state.isYes -> TronRed
                else -> TronCyan
            }

            Box(
                modifier = Modifier
                    .size(180.dp)
                    .scale(btnScale)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                btnColor.copy(alpha = 0.1f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
                    .clickable(
                        enabled = !isThinking && viewModel.question.isNotBlank(),
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        vibrate(context)
                        viewModel.askBit()
                    },
                contentAlignment = Alignment.Center
            ) {
                // Внешнее свечение
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .background(Color.Transparent, CircleShape)
                        .drawBehind {
                            drawCircle(
                                color = btnColor.copy(alpha = 0.3f),
                                radius = size.minDimension / 2,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                            )
                            drawCircle(
                                color = btnColor.copy(alpha = 0.1f),
                                radius = size.minDimension / 2 + 8.dp.toPx(),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                            )
                        }
                )

                Text(
                    text = if (isThinking) "ДУМАЮ…" else "НАЖМИ\nДЛЯ ОТВЕТА",
                    style = MaterialTheme.typography.labelLarge,
                    color = btnColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Ответ
            AnimatedVisibility(
                visible = state is BitState.Answer,
                enter = scaleIn(
                    animationSpec = tween(500, easing = EaseOutBack)
                ) + fadeIn(tween(300)),
                exit = scaleOut(tween(200)) + fadeOut(tween(200))
            ) {
                if (state is BitState.Answer) {
                    val answerColor = if (state.isYes) TronGreen else TronRed
                    val answerText = if (state.isYes) "ДА" else "НЕТ"

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = answerText,
                            style = MaterialTheme.typography.displayLarge,
                            color = answerColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.drawBehind {
                                // Glow
                                drawCircle(
                                    color = answerColor.copy(alpha = 0.2f),
                                    radius = size.maxDimension * 0.7f,
                                    center = center
                                )
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = state.phrase,
                            style = MaterialTheme.typography.labelMedium,
                            color = answerColor.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Подпись
            Text(
                text = "Вдохновлено фильмом TRON",
                style = MaterialTheme.typography.labelMedium,
                color = TronCyan.copy(alpha = 0.3f),
                textAlign = TextAlign.Center
            )
        }
    }
}

// Рисуем Tron-сетку
private fun DrawScope.drawTronGrid(offset: Float) {
    val gridSize = 40.dp.toPx()
    val lineColor = TronGridLine

    // Вертикальные линии
    var x = offset % gridSize
    while (x < size.width) {
        drawLine(
            color = lineColor,
            start = Offset(x, 0f),
            end = Offset(x, size.height),
            strokeWidth = 1f
        )
        x += gridSize
    }

    // Горизонтальные линии
    var y = offset % gridSize
    while (y < size.height) {
        drawLine(
            color = lineColor,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1f
        )
        y += gridSize
    }

    // Градиент сверху
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                TronCyan.copy(alpha = 0.03f),
                Color.Transparent,
                Color.Transparent
            )
        ),
        size = size
    )
}

// Плавающие частицы
@Composable
fun FloatingParticles() {
    val particles = remember {
        List(20) {
            ParticleData(
                x = Math.random().toFloat(),
                y = Math.random().toFloat(),
                color = if (Math.random() > 0.5f) TronCyan else TronRed,
                delay = (Math.random() * 3000).toLong(),
                duration = (2000 + Math.random() * 2000).toLong()
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        particles.forEach { particle ->
            var visible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                delay(particle.delay)
                visible = true
            }

            if (visible) {
                val anim = rememberInfiniteTransition(label = "particle")
                val offsetY by anim.animateFloat(
                    initialValue = 0f,
                    targetValue = -30f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(particle.duration.toInt(), easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "particleY"
                )

                Box(
                    modifier = Modifier
                        .offset(
                            x = (particle.x * 1000).dp,
                            y = (particle.y * 1000 + offsetY).dp
                        )
                        .size(4.dp)
                        .background(particle.color.copy(alpha = 0.6f), CircleShape)
                )
            }
        }
    }
}

data class ParticleData(
    val x: Float,
    val y: Float,
    val color: Color,
    val delay: Long,
    val duration: Long
)

// Вибрация
private fun vibrate(context: Context) {
    val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        vibratorManager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(50)
    }
}
