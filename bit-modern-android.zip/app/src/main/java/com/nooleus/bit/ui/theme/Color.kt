package com.nooleus.bit.ui.theme

import androidx.compose.ui.graphics.Color

// Tron-inspired neon palette
val TronCyan = Color(0xFF00FFFF)
val TronCyanDim = Color(0xFF00FFFF).copy(alpha = 0.3f)
val TronCyanDark = Color(0xFF003333)

val TronGreen = Color(0xFF00FF88)
val TronGreenGlow = Color(0xFF00FF88).copy(alpha = 0.6f)

val TronRed = Color(0xFFFF3366)
val TronRedGlow = Color(0xFFFF3366).copy(alpha = 0.6f)

val TronOrange = Color(0xFFFFAA00)
val TronOrangeGlow = Color(0xFFFFAA00).copy(alpha = 0.5f)

val TronBlack = Color(0xFF000000)
val TronDark = Color(0xFF0A0A0A)
val TronGrid = Color(0xFF00FFFF).copy(alpha = 0.03f)
val TronGridLine = Color(0xFF00FFFF).copy(alpha = 0.08f)
