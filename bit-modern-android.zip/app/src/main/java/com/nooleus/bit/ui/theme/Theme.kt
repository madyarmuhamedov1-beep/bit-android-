package com.nooleus.bit.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TronColorScheme = darkColorScheme(
    primary = TronCyan,
    onPrimary = TronBlack,
    secondary = TronGreen,
    onSecondary = TronBlack,
    tertiary = TronRed,
    onTertiary = TronBlack,
    background = TronBlack,
    onBackground = TronCyan,
    surface = TronDark,
    onSurface = TronCyan,
    error = TronRed,
    onError = TronBlack
)

@Composable
fun BitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = TronColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = TronTypography,
        content = content
    )
}
