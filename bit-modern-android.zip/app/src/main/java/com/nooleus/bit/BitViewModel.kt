package com.nooleus.bit

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class BitState {
    data object Idle : BitState()
    data object Thinking : BitState()
    data class Answer(val isYes: Boolean, val phrase: String) : BitState()
}

class BitViewModel : ViewModel() {

    var state by mutableStateOf<BitState>(BitState.Idle)
        private set

    var question by mutableStateOf("")
        private set

    private val yesPhrases = listOf(
        "Судьба на твоей стороне",
        "Путь открыт",
        "Данные подтверждают",
        "Система одобряет"
    )

    private val noPhrases = listOf(
        "Доступ запрещён",
        "Путь заблокирован",
        "Данные отрицают",
        "Система отклоняет"
    )

    fun onQuestionChange(newQuestion: String) {
        question = newQuestion
    }

    fun askBit() {
        if (question.isBlank()) return

        viewModelScope.launch {
            state = BitState.Thinking
            delay(1200) // Имитация "размышления" Bit

            val isYes = (0..1).random() == 1
            val phrase = if (isYes) {
                yesPhrases.random()
            } else {
                noPhrases.random()
            }

            state = BitState.Answer(isYes, phrase)
        }
    }

    fun reset() {
        state = BitState.Idle
        question = ""
    }
}
